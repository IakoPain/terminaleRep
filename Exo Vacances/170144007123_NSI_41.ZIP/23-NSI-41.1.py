def recherche(caractere, chaine):
    p=0
    for i in range(len(chaine)):
        if caractere == chaine[i]:
            p+=1
    return p
print (recherche('e', "sciences"))